//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by SimpleImgCompressApp.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_SIMPLEIMGCOMPRESSAPP_DIALOG 102
#define IDR_MAINFRAME                   128
#define IDD_TEST                        129
#define IDR_MENU_TEST                   130
#define IDD_SETTING                     131
#define IDC_STATIC_MSG                  1002
#define IDC_BT_TEST                     1003
#define IDC_ET_ALLOW                    1004
#define IDC_CK_CHIRP                    1005
#define ID_M_OPEN                       32774
#define ID_M_CUT                        32775
#define ID_M_COMPRESS                   32776
#define ID_M_SETTING                    32778

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        132
#define _APS_NEXT_COMMAND_VALUE         32779
#define _APS_NEXT_CONTROL_VALUE         1006
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
